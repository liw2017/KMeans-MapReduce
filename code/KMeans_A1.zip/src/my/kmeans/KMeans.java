package my.kmeans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.util.LineReader;

public class KMeans {
	
	public static final String defaultFS = "hdfs://0.0.0.0:19000";
    public static final String inputlocation = "hdfs://0.0.0.0:19000/user/ASUS/kmeans6/data_points.txt";
    public static final String outputlocation = "hdfs://0.0.0.0:19000/user/ASUS/kmeans6/result";
    public static final String centerInputLocation = "hdfs://0.0.0.0:19000/user/ASUS/kmeans6/center.txt";
    public static final String centerOutputLocation = "hdfs://0.0.0.0:19000/user/ASUS/kmeans6/out";
    public static final String newCenterOutput = "hdfs://0.0.0.0:19000/user/ASUS/kmeans6/out/part-r-00000";
    public static final String temp = "file:///C:\\Users\\ASUS\\AppData\\Local\\Temp\\tmp.data";
    public static Path center_inputpath = new Path(centerInputLocation);
    public static Path center_outputpath = new Path(centerOutputLocation);

	public static class PointsMapper extends Mapper<LongWritable, Text, Text, Text> {

	    List<ArrayList<String>> centers = null;
	    
	    @Override
	    protected void setup(Context context) throws IOException, InterruptedException {
	        centers = Setup.getCenterFile(centerInputLocation);
	        super.setup(context);
	    }
	    
	    @Override
	    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
	        String data = value.toString();
	        String[] tmpSplit = data.split(",");
	        List<String> parameter = new ArrayList<String>();
	        for (int i = 0; i < tmpSplit.length; i++) {
	            parameter.add(tmpSplit[i]);
	        }
	        String centerID = null;
	        double minDist = Double.MAX_VALUE;

	        for (int i = 0; i < centers.size(); i++) {
	            double distance = 0;
	            distance += Math.pow(Double.parseDouble(parameter.get(0)) - Double.parseDouble(centers.get(i).get(1)), 2);
	            distance += Math.pow(Double.parseDouble(parameter.get(1)) - Double.parseDouble(centers.get(i).get(2)), 2);

	            distance = Math.sqrt(distance);
	            if (distance < minDist) {
	            	centerID = centers.get(i).get(0);
	                minDist = distance;
	            }
	        }
	        context.write(new Text(centerID), value);

	    }
	    
		@Override
		public void cleanup(Context context) throws IOException, InterruptedException {

		}

	}
	
	public static class PointsReducer extends Reducer<Text, Text, Text, Text> {

		public static enum Counter {
			CONVERGED
		}
		
		@Override
		public void setup(Context context) {

		}
		
	    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
	    	
	        long count = 0;
	        double sum_x = 0;
	        double sum_y = 0;
	        
	        for (Text T : values) {
	            count++;
	            String onePoint = T.toString();
	            String[] parameters = onePoint.split(",");
	            sum_x += Double.parseDouble(parameters[0]);
	            sum_y += Double.parseDouble(parameters[1]);
	        }
	        double avg_sum_x = sum_x / ((double) count);
	        double avg_sum_y = sum_y / ((double) count);
	        String result = avg_sum_x + "," + avg_sum_y;
	        context.write(key, new Text(result));
	    }
	    
		@Override
		public void cleanup(Context context) throws IOException, InterruptedException {
			
		}	    
	}

    public static void main(String[] args) throws Exception {
    	
        int nCluster = Integer.parseInt(args[0]);
        int repeats = 1;
	    Path inputpath = new Path(inputlocation);
	    Path outputpath = new Path(outputlocation);       
        
        do {
            Configuration conf = new Configuration();
	        conf.set("fs.defaultFS",defaultFS);
            Job job = Job.getInstance(conf, "Get New Centers");
            job.setJarByClass(KMeans.class);
            job.setMapperClass(PointsMapper.class);
            job.setReducerClass(PointsReducer.class);
            job.setOutputKeyClass(Text.class);
            job.setOutputValueClass(Text.class);
            
            FileInputFormat.addInputPath(job, inputpath);
            FileSystem fs = center_outputpath.getFileSystem(conf);
            if (fs.exists(center_outputpath)) {
                fs.delete(center_outputpath, true);
            }
            FileOutputFormat.setOutputPath(job, center_outputpath);

            job.waitForCompletion(true);
            repeats++;
            
        } while (Setup.CleanUp_ReSet(centerInputLocation,newCenterOutput, nCluster, (float) 0.1) && repeats <= 10 );

        // Final Cluster
        Configuration final_conf = new Configuration();
        final_conf.set("fs.defaultFS",defaultFS);
        final_conf.set("center_input",centerInputLocation);
        Job final_job = Job.getInstance(final_conf, "Final Cluster");
        final_job.setJarByClass(KMeans.class);
        final_job.setMapperClass(PointsMapper.class);
        final_job.setOutputKeyClass(Text.class);
        final_job.setOutputValueClass(Text.class);
        
        FileInputFormat.addInputPath(final_job, inputpath);
        FileSystem fs = outputpath.getFileSystem(final_conf);
        if (fs.exists(outputpath)) {
            fs.delete(outputpath, true);
        }
        FileOutputFormat.setOutputPath(final_job, outputpath);

        final_job.waitForCompletion(true);

        //Output
        List<ArrayList<String>> centers = Setup.getCenterFile(centerInputLocation);
        System.out.println("Centers:");
        for(ArrayList<String> list:centers){
            System.out.println(list.toString());
        }
        
        System.out.println(" ");
        System.out.println("number of iterations is:"+repeats);
    }
	
	public static class Setup {
		
	    public static List<ArrayList<String>> getCenterFile(String inputPath) {
	    	
	        List<ArrayList<String>> centers = new ArrayList<ArrayList<String>>();
            Configuration conf = new Configuration();
	        conf.set("fs.defaultFS",defaultFS);	        
	        
	        try {
	            FileSystem fs = center_inputpath.getFileSystem(conf);
	            Path path = new Path(inputPath);
	            FSDataInputStream fsIn = fs.open(path);
	            Text lineText = new Text();
	            String tmpStr = null;
	            LineReader linereader = new LineReader(fsIn, conf);
	            while (linereader.readLine(lineText) > 0) {
	                ArrayList<String> oneCenter = new ArrayList<String>();
	                tmpStr = lineText.toString();
	                String[] tmp = tmpStr.replace("\t", ",").split(",");
	                for (int i = 0; i < tmp.length; i++) {
	                    oneCenter.add(tmp[i]);
	                }
	                centers.add(oneCenter);
	            }
	            fsIn.close();
	            linereader.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return centers;
	    }
	    
	    public static boolean CleanUp_ReSet(String inputpath, String outputpath, int k, float threshold) throws IOException {
	    	
	        List<ArrayList<String>> oldcenters = Setup.getCenterFile(inputpath);
	        List<ArrayList<String>> newcenters = Setup.getCenterFile(outputpath);

	        float distance = 0;
	        for (int i = 0; i < k; i++) {
	            for (int j = 1; j < oldcenters.get(i).size(); j++) {
	                try {
	                    float tmp = Math.abs(Float.parseFloat(oldcenters.get(i).get(j)) - Float.parseFloat(newcenters.get(i).get(j)));
	                    distance += Math.pow(tmp, 2);
	                }catch (Exception e){
	                    throw new IllegalArgumentException(inputpath+"\n"+outputpath+"\n"+oldcenters.toString()+"\n"+newcenters.toString());
	                }
	            }
	        }

	        Configuration conf = new Configuration();
	        conf.set("fs.defaultFS",defaultFS);
	        //deleteLastResult
	        try {
	            FileSystem fs2 = FileSystem.get(conf);
	            fs2.delete(new Path(inputpath), true);
	        } catch (IOException i) {
	            i.printStackTrace();
	        }
	        
	        Path tempPath = new Path("/tmp");
	        FileSystem fs = tempPath.getFileSystem(conf);
	        fs.moveToLocalFile(new Path(outputpath), new Path(temp));
	        fs.moveFromLocalFile(new Path(temp), new Path(inputpath));
	        return distance > threshold;
	    }

	}
	
}
